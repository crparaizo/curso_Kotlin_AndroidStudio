package com.farias.projectkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                view?.loadUrl(url)
                return true
            }
        }
        webView.loadUrl("https://www.google.com/")


        imgSearch.setOnClickListener{

            var search = edtSite.text.toString().trim()

            if (search.isEmpty()){
                Toast.makeText(this@MainActivity, "Informe a sua pesquisa ou digite seu site", Toast.LENGTH_LONG).show()
            } else if (search.contains(".com")){
                webView.loadUrl("https://$search")
            }
            else {
                webView.loadUrl("https://www.google.com/search?q=$search")
            }
        }

        imgBack.setOnClickListener {
            if (webView.canGoBack())
                webView.goBack()
        }
        imgFront.setOnClickListener {
            if (webView.canGoForward())
                webView.goForward()
        }

        imgRefresh.setOnClickListener{
            var search = edtSite.text.toString().trim()

            if (search === ""){
                Toast.makeText(this@MainActivity, "Informe a sua pesquisa", Toast.LENGTH_LONG).show()
            } else if (search.contains(".com")){
                webView.loadUrl("https://$search")
            }
            else {
                webView.loadUrl("https://www.google.com/search?q=$search")
            }
        }
    }
}
