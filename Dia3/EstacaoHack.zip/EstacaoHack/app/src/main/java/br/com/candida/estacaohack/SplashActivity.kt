package br.com.candida.estacaohack

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        //Setando um tempo na tela de Splash para a tela de Login
        Handler().postDelayed({
            //Abrindo a tela de Login
            startActivity(Intent(this@SplashActivity, LoginActivity::class.java)) //Alt + Enter para importar uma classe
            //Finalizando a Splash - pois ao se usar o Intent, é aberto uma tela em cima da outra, pesando no desempenho
            finish()
        }, 3000)
    }
}
