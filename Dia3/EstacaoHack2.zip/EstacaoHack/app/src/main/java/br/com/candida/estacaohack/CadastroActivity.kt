package br.com.candida.estacaohack

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_cadastro.*

class CadastroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)

        /*
        Criando o Shared Preference:
        São necessários dois parâmentros dentro dos parênteses
        1º - Nome do arquivo a ser criado
        2º - O modo de acesso dele
        */

        val minhaPreferencia = getSharedPreferences("minha-preferencia", Context.MODE_PRIVATE)

        //Criando o Editor do SharedPreferences

        val meuEditor = minhaPreferencia.edit()

        //Criando a lista sexo

        val listaSexo = arrayListOf("Selecione o sexo", "Feminino", "Masculino")

        //Criando o adaptador do Spinner ( todos desse tipo necessitam )
        val adapterSexo = ArrayAdapter(
            this@CadastroActivity,
            android.R.layout.simple_spinner_dropdown_item,
            listaSexo
        )

        //Adicionando o adaptador ao spinner da tela
        spnSexo.adapter = adapterSexo

        //Evento do clique do botão
        btnCadastrar.setOnClickListener {
            //Recuperando os valores digitados pelo usuário e armazenando em variáveis
            val nome = txvNome.text.toString().trim()
            val sobrenome = edtSobrenome.text.toString().trim()
            val email = txvEmail.text.toString().trim().toLowerCase()
            val senha = edtSenha.text.toString().trim()

            //Validando se todos os campos estão preenchidos e se o sexo foi selecionado
            if (nome.isEmpty() || sobrenome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
                //Imprimindo uma mensagem de erra pro usuário através do Toast
                Toast.makeText(this@CadastroActivity, "Preencha todos os campos", Toast.LENGTH_LONG)
                    .show()
            } else if (spnSexo.selectedItem == "Selecione o sexo") {
                //Imprimindo uma mensagem de erro pro usuário
                Toast.makeText(this@CadastroActivity, "Preencha o campo SEXO", Toast.LENGTH_LONG)
                    .show()
            } else {
                //Salvando as informações no Shared Preferences
                meuEditor.putString("nome", nome).apply()
                meuEditor.putString("sobrenome", sobrenome).apply()
                meuEditor.putString("email", email).apply()
                meuEditor.putString("senha", senha).apply()
                meuEditor.putString("sexo", spnSexo.selectedItem.toString()).apply()

                //Criando o alerta de usuário cadastrado com sucesso

                /*
                Acrescentado uma mensagem no Alerta:
                Para adicionar título: setTitle
                Para adicionar mensagem: setMassage
                Para adicionar botão positivo: setPositiveButton
                 */

                AlertDialog.Builder(this@CadastroActivity)
                    .setTitle("Sucesso")
                    .setMessage("Usuário Cadastrado!")
                    .setPositiveButton("Ok")
                    { _, _ ->
                        //Voltado para o tela de login
                        //OnBackPressed()
                        startActivity(Intent(this@CadastroActivity, MainActivity::class.java))
                    }
                    .create()
                    .show()

            }
        }
    }
}
