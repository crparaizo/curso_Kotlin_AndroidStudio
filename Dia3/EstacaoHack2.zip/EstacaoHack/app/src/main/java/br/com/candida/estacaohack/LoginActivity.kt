package br.com.candida.estacaohack

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        //Criando a ação do clique do botão Entrar:
        btnEntrar.setOnClickListener {

            val usuario =
                edtUsuario.text.toString().trim() //Transforma em string e trata os espaços
            val senha = edtSenha.text.toString().trim()

            //Condição para verificar o usuário e a senha:

            if (usuario.isEmpty()) {
                txvResultado.text = "Campo usuário está vazio!!!"
            } else if (senha.isEmpty()) {
                txvResultado.text = "Campo senha está vazio!!!"
            } else if (usuario == "candida" && senha == "candida") {
                txvResultado.text = "Usuário logado com SUCESSO!"

            } else {
                Toast.makeText(
                    this@LoginActivity,
                    "Usuário ou senha incorreta :(",
                    Toast.LENGTH_LONG
                )
                    .show() //parametro: onde eu estou (nome da página), o texto da mensagem e duração da mensagem
            }
        }

        btnCadastrar.setOnClickListener {
            startActivity(Intent(this@LoginActivity, CadastroActivity::class.java))
        }
    }
}